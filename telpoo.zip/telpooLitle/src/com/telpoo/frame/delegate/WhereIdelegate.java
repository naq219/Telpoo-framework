package com.telpoo.frame.delegate;

public class WhereIdelegate {
	public static final int DIALOGUTILS_DATEPICKER=1001;
	public static final int DIALOGUTILS_DATEPICKER_MONTH_YEAR=1002;
}

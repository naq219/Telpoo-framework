package com.telpoo.frame.delegate;

public interface IChanceListener {
	void onChance(int where);
}

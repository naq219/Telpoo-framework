package com.telpoo.frame.delegate;

public interface GAListener {
	public void setName(String name);
}

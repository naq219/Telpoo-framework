package com.telpoo.frame.delegate;

public interface Idelegate {
	public void callBack(Object value , int where);
	
}

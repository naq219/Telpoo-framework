/** Automatically generated file. DO NOT MODIFY */
package com.telpoo.frame;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}